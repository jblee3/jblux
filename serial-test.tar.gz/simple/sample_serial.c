#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>


#include <linux/types.h>
#include <linux/serial.h>       // [FG]


#include <termios.h>
#include <sys/signal.h>
#include <sys/types.h>


int	XFER_LEN = 32;

//------------------------------------------------------------------------------
// ���� : Test Main
//------------------------------------------------------------------------------
int     main( int argc, char **argv )
{
        int fd,c, res;
        struct termios oldtio,newtio;
        char buf[255];
        
        int	idx, rtn;
        int	baud = 9600;
        int	c_rs485 = 0; 
        int	wr_open  = 0;
        int	pingpong = 0;
        char	strport[128] = "ttyS00";
        char 	dev_name[255];
        

	if ( argc == 1 )
	{
		printf( "\n" );
		printf( " s[ttyS0..]         * serial-port node\n" );
		printf( " b[2400..115200/230400/460800] * baud-rate\n"          );
		printf( " c               * ctrl RS485\n"         );
		printf( " r               * read open\n"          );
		printf( " w               * write open\n"         );
		printf( " x               * ping-pong\n"          );
		printf( "\n" );
			   			 
		return 0;	
	}

	for (idx=1; idx<argc; idx++)
	{
		switch ( argv[idx][0] )
		{
		// Port Number
		case 'S': case 's':
			strcpy( strport, &(argv[idx][1]) ); 
			break;
		
		case 'B': case 'b':
			baud = strtoul( &(argv[idx][1]), NULL, 0 ); 
			break;

		case 'C': case 'c':
			c_rs485 = 1;
			break;
			
		case 'R': case 'r':
			wr_open = 0;
			break;

		case 'W': case 'w':
			wr_open = 1;
			break;
		
		case 'X': case 'x':
			pingpong = 1;
			break;
		
		case 'N': case 'n':
			XFER_LEN = strtoul( &(argv[idx][1]), NULL, 0 ); 
			break;
		}
	}

	sprintf( dev_name, "/dev/%s", strport );
        fd = open( dev_name, O_RDWR | O_NOCTTY );
        if (fd <0) 
        {
                // ȭ�� ���� ����
                printf( "Device OPEN FAIL %s\n", dev_name );
                return -1;
        }

        tcgetattr(fd,&oldtio); // ���� ������ oldtio�� ����

        memset(&newtio, 0, sizeof(newtio));
        newtio.c_iflag = IGNPAR;
        newtio.c_oflag = 0;

	newtio.c_cflag = CS8 | CLOCAL | CREAD;
	switch( baud )
	{
	case 460800 : newtio.c_cflag |= B460800; break;
	case 230400 : newtio.c_cflag |= B230400; break;
	case 115200 : newtio.c_cflag |= B115200; break;
	case 57600  : newtio.c_cflag |= B57600;  break;
	case 38400  : newtio.c_cflag |= B38400;  break;
	case 19200  : newtio.c_cflag |= B19200;  break;
	case 9600   : newtio.c_cflag |= B9600;   break;
	case 4800   : newtio.c_cflag |= B4800;   break;
	case 2400   : newtio.c_cflag |= B2400;   break;
	}

        newtio.c_cc[VTIME] = 0;  // timeout TIME*0.1
        newtio.c_cc[VMIN]  = 1; //XFER_LEN;   // [1] �ּ� n ���� ���� ������ blocking 

        tcflush(fd, TCIFLUSH);
        tcsetattr(fd,TCSANOW,&newtio);

	if ( c_rs485 ) 
	{
		rtn = ioctl( fd, 0x54F0, 0x0001 );
		if ( 0 < rtn )
		{
			printf( "ioctl Error %d\n", rtn );	
		}
	}


        if ( wr_open )
        {
		printf( " Write Open %s %d\n", dev_name, baud );
		while(1)
                {
                        // write
                        for ( c='A'; c<='Z'; c++ )
                        {
                                memset( buf, c, XFER_LEN );
                                //printf( " %s\n", buf );
                                write( fd, buf, XFER_LEN );
                		
                		if ( pingpong )
                		{
                			res = read(fd,buf,255);   
                        		buf[res]=0;               
                        		if ( 0 < res ) printf("%s) %s:%d\n", strport, buf, res);
                        	}
                        	
                                sleep(1);
                        }
		}
        }
	else
        {        
		printf( " Read Open %s %d\n", dev_name, baud );
        	// read
                while (1) 
                {       
                	res = read(fd,buf,255);   
                        buf[res]=0;               
                        if ( 0 < res ) printf("%s) %s:%d\n", strport, buf, res);
						for (idx =0; idx<res; idx++)
						{
//							printf( " %02x", buf[idx] );
						}	
//						if ( 0 < res ) printf("\n" ); 
                        
                        if ( pingpong ) write( fd, buf, res );
                }
        }

        tcsetattr(fd,TCSANOW,&oldtio);

        close( fd );
        return 0;
}

