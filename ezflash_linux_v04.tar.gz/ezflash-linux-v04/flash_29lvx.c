//------------------------------------------------------------------------------
// ȭ�ϸ�   : FB29LVx.c
// ������Ʈ : ezboot
// ��  ��   : ezboot�� FB29LVxflash ó�� ��ƾ�̴�. 
// 
// �ۼ���   : ����â (��)���̴���Ƽ frog@falinux.com
//            ����� (��)���̴���Ƽ freefrug@falinux.com
// �ۼ���   : 2003�� 5�� 23��
//            2003�� 6�� 05��
// ���۱�   : (��)���̴���Ƽ 
// ��  �� : 
//------------------------------------------------------------------------------
//******************************************************************************
//
// ��� ����
//
//******************************************************************************
#include <stdio.h>
#include <stdlib.h>
#include <asm/io.h>
#include <unistd.h>
#include <string.h>
#include <memory.h>

#include "jtag.h"
#include "pxa255.h"
#include "flash_29lvx.h"

// flash block
const int FB29LV400T_block_addr[] = 
		{ 0x00000, 0x10000, 0x20000, 0x30000, 
		  0x40000, 0x50000, 0x60000, 0x70000,
		  0x78000, 0x7A000, 0x7C000,
		  -1
		};

const int FB29LV400B_block_addr[] = 
		{ 0x00000, 0x04000, 0x06000, 0x08000, 
		  0x10000, 0x20000, 0x30000, 0x40000,
		  0x50000, 0x60000, 0x70000,
		  -1
		};
		
const int FB29LV800T_block_addr[] = 
		{ 0x00000, 0x10000, 0x20000, 0x30000, 
		  0x40000, 0x50000, 0x60000, 0x70000,
		  0x80000, 0x90000, 0xA0000, 0xB0000,
		  0xC0000, 0xD0000, 0xE0000, 0xF0000,
		  0xF8000, 0xFA000, 0xFC000,
		  -1
		};

const int FB29LV800B_block_addr[] = 
		{ 0x00000, 0x04000, 0x06000, 0x08000, 
		  0x10000, 0x20000, 0x30000, 0x40000,
		  0x50000, 0x60000, 0x70000, 0x80000,
		  0x90000, 0xA0000, 0xB0000, 0xC0000,
		  0xD0000, 0xE0000, 0xF0000,
		  -1
		};

const int FB29LV160T_block_addr[] = 
		{ 0x000000, 0x010000, 0x020000, 0x030000, 
		  0x040000, 0x050000, 0x060000, 0x070000,
		  0x080000, 0x090000, 0x0A0000, 0x0B0000,
		  0x0C0000, 0x0D0000, 0x0E0000, 0x0F0000,
		  0x100000, 0x110000, 0x120000, 0x130000, 
		  0x140000, 0x150000, 0x160000, 0x170000,
		  0x180000, 0x190000, 0x1A0000, 0x1B0000,
		  0x1C0000, 0x1D0000, 0x1E0000, 0x1F0000,
		  0x1F8000, 0x1FA000, 0x1FC000,
		  -1
		};

const int FB29LV160B_block_addr[] = 
		{ 0x000000, 0x004000, 0x006000, 0x008000,
		  0x010000, 0x020000, 0x030000, 0x040000,
		  0x050000, 0x060000, 0x070000, 0x080000,
		  0x090000, 0x0A0000, 0x0B0000, 0x0C0000,
		  0x0D0000, 0x0E0000, 0x0F0000, 0x100000,
		  0x110000, 0x120000, 0x130000, 0x140000, 
		  0x150000, 0x160000, 0x170000, 0x180000,
		  0x190000, 0x1A0000, 0x1B0000, 0x1C0000,
		  0x1D0000, 0x1E0000, 0x1F0000,
		  -1
		};	

#define	RETRY_COUNT			400
#define	WAIT_LOOP_COUNT		200


// �÷��� ���� ����
int	Flash_PID   = 0;	// �÷��ø� �����Ѵ�.
int	BlockCount  = 0;
int	FlashSize   = 0;
int	*pBlockAddr = FB29LV160B_block_addr;

//------------------------------------------------------------------------------
// ���� : ������¸� ǥ�� �Ѵ�. 
// �Ű� : title : �������� 
//        cur   : ���� ���൵ 
//        max   : �ִ밪
// ��ȯ : 
// ���� : ���� 
//------------------------------------------------------------------------------

int progress_pos = 0;
int dpywidth = 40;
char bar[] =
	"==============================================================="
	"===============================================================";
char spaces[] =
	"                                                               "
	"                                                               ";
void 	Flash_UpdateProgress(const char *title,   unsigned long cur, unsigned long max)
{
	const char spinner[] = "\\|/-";
	unsigned int percent;
	int i;

	progress_pos = (progress_pos+1) & 3;
	percent = (cur * 100) / max;
	i = ((percent * dpywidth) + 50) / 100;
	printf("%s: |%s%s", title,
		bar + (sizeof(bar) - (i+1)),
		spaces + (sizeof(spaces) - (dpywidth - i + 1)));
	if (percent == 100)
		printf("|");
	else
		printf("%c", spinner[progress_pos & 3] );
	printf(" %4d%%   \r", percent);
	if (percent == 100)	/* clear prog bar */
		printf("%s\r", spaces + (sizeof(spaces) - 80));
}
//-----------------------------------------------------------------------------
//  �� �� : Wait
//  �� ȯ :
//-----------------------------------------------------------------------------
void	dumy( void )
{
	return;	
}
void	FB29LVx_Wait( void )
{
	int	loop = WAIT_LOOP_COUNT;
	
	while( loop-- ) { dumy(); };
}
//-----------------------------------------------------------------------------
//  �� �� : RESET ��Ű�� ����
//  �� ȯ :
//------------------------------------------------------------------------------
void 	FB29LVx_CMD_RESET( DWORD vBase )
{
   	FB29LVx_WriteMemoryShort( vBase, 0xF0 ); 
}
//------------------------------------------------------------------------------
//  �� �� : ID �� �д� ����
//  �� ȯ :
//-----------------------------------------------------------------------------
void 	FB29LVx_CMD_READID_SETUP( DWORD vBase )
{
    	FB29LVx_WriteMemoryShort( vBase + (0x555<<1), 0xAA ); 
    	FB29LVx_WriteMemoryShort( vBase + (0x2AA<<1), 0x55 ); 
    	FB29LVx_WriteMemoryShort( vBase + (0x555<<1), 0x90 ); 
}
//------------------------------------------------------------------------------
//  �� �� : ����Ÿ�� �� �ִ´�.
//  �� ȯ :
//-----------------------------------------------------------------------------
void 	FB29LVx_CMD_WRITE( unsigned long vBase, unsigned long vOffset, WORD vData)
{
    	FB29LVx_WriteMemoryShort( vBase+(0x555<<1), 0xAA  );  
    	FB29LVx_WriteMemoryShort( vBase+(0x2AA<<1), 0x55  );  
    	FB29LVx_WriteMemoryShort( vBase+(0x555<<1), 0xA0  );  
    	FB29LVx_WriteMemoryShort( vBase+vOffset   , vData );  
}
//------------------------------------------------------------------------
// �� �� : ���� ���� ������ ����� ��´�. 
// �� ȯ : 
//------------------------------------------------------------------------
int 	FB29LVx_GetStatus( unsigned long vBase )
{
    	unsigned char status, XorStatus;
	
    	while(1)
    	{
 		status     = FB29LVx_ReadMemoryShort( vBase );
 		XorStatus  = status ^ FB29LVx_ReadMemoryShort( vBase );
 		XorStatus &= ((1<<6)|(1<<2));	// Q6, Q2
	 	
 		// �ð��ʰ��� Ȯ���Ѵ�.
 		if ( status & (1<<5) ) 		// Q5
 		{
 			return FB29LVx_STATUS_TIMEOUT;  
 		}
 		
 		// suspend 
 		if ( status & (1<<7) ) 
 		{
 			return FB29LVx_STATUS_ERSUSP; 
 		}
 		
 		// ��ȭ�� ���ٸ� �������̴�. 
 		if ( XorStatus == 0 ) 
 		{
 			return FB29LVx_STATUS_READY; 
 		}
    	}

    	return FB29LVx_STATUS_ERROR;                         // ������ ����.  
}
//------------------------------------------------------------------------
//  �� �� : Flash�� ������ ��´�. 
//  �� ȯ : 
//------------------------------------------------------------------------
int 	FB29LVx_Detect( DWORD vBase )
{
    	unsigned short	mid, pid;
    	char     mid_str[32];

    	FB29LVx_CMD_RESET( vBase ); 
    	FB29LVx_CMD_READID_SETUP(vBase);  
    	
    	// ������ ȸ���ڵ�
    	mid = FB29LVx_ReadMemoryShort( vBase + 0      );
    	// �÷��� ��ǰ�ڵ�
    	pid = FB29LVx_ReadMemoryShort( vBase + (1<<1) );

		FB29LVx_CMD_RESET( vBase ); 

    	switch (mid)
    	{
    	case MXIC_MID : strcpy( mid_str, "MX" );	break;
    	case AMD_MID  : strcpy( mid_str, "AM" );	break;
		case ES_MID   : strcpy( mid_str, "ES" );    break;						
		case EON_MID  : strcpy( mid_str, "EN" );	break;
		default       : strcpy( mid_str, "xx" );	break;
    	//default : printf( "> Error Detect Code : %02x\n", mid );
    	//	  return -1; 
    	}
    	
    	switch (pid)
    	{
    	case FB_DID_400T:

			Flash_PID   = pid;	// �÷��ø� �����Ѵ�.
			BlockCount  = FB_400x_BLOCK_COUNT;
			FlashSize   = 512*1024;
			pBlockAddr  = (int *)FB29LV400T_block_addr;
		
    		printf( "  Detect %s29LV400 (TOP)Flash : %04X\n", mid_str, pid );
    		printf( "  SIZE 4M-BIT [512Kbyte]\n");
			break;

		case FB_DID_400B:

			Flash_PID   = pid;	// �÷��ø� �����Ѵ�.
			BlockCount  = FB_400x_BLOCK_COUNT;
			FlashSize   = 512*1024;
			pBlockAddr  = (int *)FB29LV400B_block_addr;
		
    		printf( "  Detect %s29LV400 (BOTTOM)Flash : %04X\n", mid_str, pid );
   			printf( "  SIZE 4M-BIT [512Kbyte]\n");
			break;
	    	
    	case FB_DID_800T:

			Flash_PID   = pid;	// �÷��ø� �����Ѵ�.
			BlockCount  = FB_800x_BLOCK_COUNT;
			FlashSize   = 1024*1024;
			pBlockAddr  = (int *)FB29LV800T_block_addr;
		
    		printf( "  Detect %s29LV800T (TOP)Flash : %04X\n", mid_str, pid );
    		printf( "  SIZE 8M-BIT [1Mbyte]\n");
			break;

		case FB_DID_800B:

			Flash_PID   = pid;	// �÷��ø� �����Ѵ�.
			BlockCount  = FB_800x_BLOCK_COUNT;
			FlashSize   = 1024*1024;
			pBlockAddr  = (int *)FB29LV800B_block_addr;
		
    		printf( "  Detect %s29LV800T (BOTTOM)Flash : %04X\n", mid_str, pid );
   			printf( "  SIZE 8M-BIT [1Mbyte]\n");
			break;

    	case FB_DID_160T:

			Flash_PID   = pid;	// �÷��ø� �����Ѵ�.
			BlockCount  = FB_160x_BLOCK_COUNT;
			FlashSize   = 2048*1024;
			pBlockAddr  = (int *)FB29LV160T_block_addr;
		
    		printf( "  Detect %s29LV160T (TOP)Flash : %04X\n", mid_str, pid );
    		printf( "  SIZE 16M-BIT [2Mbyte]\n");
			break;

    	case FB_DID_160B:

			Flash_PID   = pid;	// �÷��ø� �����Ѵ�.
			BlockCount  = FB_160x_BLOCK_COUNT;
			FlashSize   = 2048*1024;
			pBlockAddr  = (int *)FB29LV160B_block_addr;
		
    		printf( "  Detect %s29LV160B (BOTTOM)Flash : %04X\n", mid_str, pid );
    		printf( "  SIZE 16M-BIT [2Mbyte]\n");
			break;    	

    	default:
    		printf( "  Unknown Flash : pid=%04X\n", pid );
			return FALSE; 
    	} 

	return TRUE;
}

//------------------------------------------------------------------------------
//  �� �� : ������ �����.
//  �� ȯ : ���� 0
//  �� �� : �ݵ�� ������ �ּҸ� �ش�
//-----------------------------------------------------------------------------
int 	FB29LVx_EraseBlock( unsigned long vBase, unsigned long vBlkAddr )
{
   	WORD	status;
      	int	loop;
      	
      	for (loop=0; loop<RETRY_COUNT; loop++)
      	{
       		FB29LVx_WriteMemoryShort( vBase+(0x555<<1), 0xAA ); 
       		FB29LVx_WriteMemoryShort( vBase+(0x2AA<<1), 0x55 ); 
       		FB29LVx_WriteMemoryShort( vBase+(0x555<<1), 0x80 ); 
       		FB29LVx_WriteMemoryShort( vBase+(0x555<<1), 0xAA ); 
       		FB29LVx_WriteMemoryShort( vBase+(0x2AA<<1), 0x55 ); 
       	
       		FB29LVx_WriteMemoryShort( vBase+vBlkAddr, 0x30 ); 
       	
   			while (( status = FB29LVx_GetStatus(vBase) ) == FB29LVx_STATUS_BUSY ) {}
      	
	      	switch( status )
    	  	{
			case FB29LVx_STATUS_READY:    FB29LVx_CMD_RESET(vBase); return 0;  
			case FB29LVx_STATUS_BUSY: 	  			continue;
			case FB29LVx_STATUS_ERSUSP:   FB29LVx_CMD_RESET(vBase);	continue; 
			case FB29LVx_STATUS_TIMEOUT:  FB29LVx_CMD_RESET(vBase); continue;  	
			default:  printf( "Erase Error [status]...\n" ); 		return -1;
      		}  	
       	}
       	
       	printf( "Erase Error [retry count]...\n" ); 		
       	return -1;
}
//------------------------------------------------------------------------
//  �� �� : Flash�� ����Ÿ�� ����.
//  �� ȯ : ���� 0
//------------------------------------------------------------------------
int 	FB29LVx_WriteWord( DWORD vBase, DWORD vOffset, WORD data )
{
      	WORD	status;
      	int		loop;
      	
      	for (loop=0; loop<RETRY_COUNT; loop++)
      	{
      		FB29LVx_CMD_WRITE( vBase, vOffset, data & 0xffff );  // ����Ÿ�� �� �ִ´�.
      
   			status = FB29LVx_GetStatus( vBase );
   			if ( status == FB29LVx_STATUS_READY )
   			{
   				FB29LVx_Wait();
   				return 0;  
   			}
   			else
   			{
   				FB29LVx_CMD_RESET(vBase); 	
   			}
		}
		printf( "Write Error [retry count]...\n" ); 
		return -1;	
}
//------------------------------------------------------------------------------
//  �� �� : offset �ּҿ��� ������ȣ�� ã�´�.
//  �� ȯ : ������ȣ
//-----------------------------------------------------------------------------
int	FB29LVx_GetBlockIndex( unsigned long vOffset )
{
	int	blk;
	
	// �÷��� ũ����� �ּҸ� �Ÿ���.
	if ( FlashSize <= vOffset ) return -1;
	
	// ������ȣ�� ã�´�.
	for (blk=0; blk<BlockCount; blk++)
	{
		if ( 0 > pBlockAddr[blk] )
		{
			return -1; // �������� �ʴ� �ּ��̴�.
		}
		
		if ( 0 < pBlockAddr[blk+1] )
		{
			if ( ( pBlockAddr[blk] <= vOffset ) &&  ( vOffset < pBlockAddr[blk+1] ) )
			{
				break; // ������ȣ�� ã�Ҵ�.
			}
		}
		else
		{
			break;	// ������ ����
		}
	}
	
	return blk;
}
//------------------------------------------------------------------------
// �� �� : Flash�� �����ϱ� ���� �ʱ�ȭ�� �����Ѵ�. 
// �� �� : 
//------------------------------------------------------------------------
void 	Flash_Init( void )
{
	PXA255_DebugSetIR( PXA255_IR_EXTEST );
}
//------------------------------------------------------------------------
// �� �� : Flash�� ID �� �д´�.
// �� �� : 
//------------------------------------------------------------------------
BOOL 	Flash_Detect( DWORD vBase )
{
	return FB29LVx_Detect( vBase );
}
//------------------------------------------------------------------------------
// ���� : Flash�� ����Ÿ�� �� �ִ´�. 
// �Ű� : dest : �÷��� ���� ���� �ּ� 
//        src  : �� �б� ���� �ּ�  
//        size : ����� ũ�� 
// ��ȯ : 
// ���� : ���� 
//------------------------------------------------------------------------------
int 	Flash_Program( DWORD  vBase, DWORD  vOffset, char *src, DWORD size )
{
	int	s_blk, e_blk;
	int	idx;
	WORD	wData;

	
	// ���� ������ ���۰� ���� ã�´�.
	s_blk = FB29LVx_GetBlockIndex( vOffset );
	e_blk = FB29LVx_GetBlockIndex( vOffset + size );
	if ( ( s_blk < 0 ) || ( e_blk < 0 ) ) 
	{
		printf( "Invalid Address... 0x%08x\n", vBase+vOffset );
		return -1;
	}
	
	// ����� ������ ������ �����. 
	for ( idx=s_blk; idx<=e_blk; idx++ )
	{
		Flash_UpdateProgress( "    Erasing", idx-s_blk+1, e_blk-s_blk+1 );
		
		if ( 0 > FB29LVx_EraseBlock( vBase, pBlockAddr[idx] ) ) return -1;
		sleep(1);
	}
	Flash_UpdateProgress( "    Erasing", 100, 100 );
	printf( "    Erase : OK\n" );

	sleep(1); 
	
	for ( idx=0; idx<size; idx+=2 )
	{
		if ( 0 == idx % 50 )
			Flash_UpdateProgress("    Writing", idx, size );
		
		wData = (src[idx]&0xff) | ( (src[idx+1]&0xff) << 8 );
		if ( 0 > FB29LVx_WriteWord( vBase, vOffset+idx, wData ) ) return -1;
	}
	Flash_UpdateProgress( "    Writing", 100, 100 );
	printf( "    Write : OK\n" );
	
	return size;
}
//------------------------------------------------------------------------
// �� �� : Flash�� �޸𸮸� �д´�. 
// �� �� : 
//------------------------------------------------------------------------
WORD 	Flash_InWord( DWORD vAddress )
{
   	WORD Value;

   	Value = PXA255EZ_ReadMemory( vAddress ) & 0xFFFF;
   	return Value;
}
//------------------------------------------------------------------------
// �� �� : Flash���� �޸𸮸� �д´�. 
// �� �� : 
//------------------------------------------------------------------------
void 	Flash_DebugReadMemory( void )
{
    	DWORD         StartAddress;
    	DWORD         EndAddress  ;
    	int           lp, lp1;
    	BYTE          Data[16];
    	WORD          WData;

    	printf( "? Read Start Address ?[ ex) 000 ] : " );
    	scanf( "%x", &StartAddress );
    	printf( "? Read End   Address ?[ ex) 800 ] : " );
    	scanf( "%x", &EndAddress );

    for( lp1 = StartAddress; lp1 <= EndAddress; lp1 += 16 )
    {
        // ����Ÿ�� �д´�. 
        for( lp = 0; lp < 8; lp++ )
        {
          WData = Flash_InWord( lp1 + lp * 2  );
          Data[ lp * 2 + 0 ] =  (BYTE) (   WData       & 0xFF );
          Data[ lp * 2 + 1 ] =  (BYTE) ( ( WData >> 8 ) & 0xFF );
        }

        // �ּ� ǥ�� 
        printf( "    %04X %04X :",  ( ( (DWORD) lp1       ) >> 16 ) & 0xFFFF,
                                    ( (DWORD) lp1       )         & 0xFFFF
              );

        // �� 4�� ǥ�� 
        for( lp = 0; lp < 16; lp++ )
        {
            printf( "%02X", Data[ lp ] & 0xFF );
            printf( " " );
        }

        printf( "  " );
        for( lp = 0; lp < 16; lp++ )
        {
            if      ( Data[lp] < ' ' ) printf( "." );
            else if ( Data[lp] > '~' ) printf( "." ); 
            else    printf("%c", Data[lp]  );
        } 
        printf( "\n" );

    }
}
//------------------------------------------------------------------------
// �� �� : Flash���� ������ �ڷḦ �� �ִ´�. 
// �� �� : 
//------------------------------------------------------------------------
void 	Flash_DebugWriteMemory( void )
{
    DWORD         BaseAddress  ; 
    DWORD         OffsetAddress;
    DWORD         Size;
    char          *TestBuff;
    int           lp;

    printf( "? Write Base   Address ?[ ex) 000 ] : " );
    scanf( "%x", &BaseAddress );
    printf( "? Write Offest Address ?[ ex) 800 ] : " );
    scanf( "%x", &OffsetAddress );
    printf( "? Write Size           ?[ ex) 256 ] : " );
    scanf( "%d", &Size );

    TestBuff = malloc( Size );

    for( lp = 0; lp < Size; lp++ ) TestBuff[ lp ] = (char) ( lp & 0xff );

    Flash_Detect ( BaseAddress );

    Flash_Program( BaseAddress, OffsetAddress, TestBuff, Size );

    free( TestBuff ); 
   
}

//------------------------------------------------------------------------
// �� �� : Flash���� ������ �ڷḦ �� �ִ´�. 
// �� �� : 
//------------------------------------------------------------------------
void 	Flash_DebugDectect( void )
{
    DWORD         BaseAddress  ; 

    printf( "? Base   Address ?[ ex) 000 ] : " );
    scanf( "%x", &BaseAddress );

    Flash_Detect ( BaseAddress );

}
//------------------------------------------------------------------------
// �� �� : PXA255�� ���� ����� ����Ѵ�. 
// �� �� : ���� 
// �� ȯ : ���� 
// �� �� : ���� 
//------------------------------------------------------------------------
void 	Flash_DebugCommandList( void )
{
    printf( "# Flash DEBUG MODE\n" );
    printf( "# r) Flash Read \n" );
    printf( "# w) Flash Write \n" );
    printf( "# d) Flash Detect Test \n" );

    printf( "# h) Command List\n" );
    printf( "# q) Quit\n" );
    printf( "------------------------------------------------------------\n" );
}

//------------------------------------------------------------------------
// �� �� : PXA255 JTAG �� �����Ѵ�. 
// �� �� : ���� 
// �� ȯ : ���� 
// �� �� : ���� 
//------------------------------------------------------------------------
void 	Flash_Debug( void )
{
    	char	cmd;
    	int	idx;

    	printf( "# JTAG Change Run Test Idle Mode\n" );
    	JTAG_RunTestldle(); 
    	PXA255_Init();
    	Flash_Init();

    	Flash_DebugCommandList();

    	while( 1 )
    	{ 
        	printf("\r Command ? " );
        	cmd =  getchar();
     
        	switch( cmd )
        	{
            	case 'q' : return;
            	case 'h' : Flash_DebugCommandList(); break;
            	case 'r' : Flash_DebugReadMemory (); break;
            	case 'w' : Flash_DebugWriteMemory(); break;
            	case 'd' : Flash_DebugDectect();     break;
            	
            	case 't' : for (idx=0; idx<100; idx++)
            		   {
				Flash_Detect( 0 );
				sleep(1);
            		   }
        	} 
    	}
}



